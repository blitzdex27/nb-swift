import Foundation

struct StringWrapper {
    var storage: String
}

struct IntWrapper {
    var storage: Int
}

struct DateWrapper {
    var storage: Date
}

import Foundation


func equals(lhs: Int, rhs: Int) -> Bool {
    // The iplementation is straightforward
    return lhs == rhs
}

print(equals(lhs: 3, rhs: 4))

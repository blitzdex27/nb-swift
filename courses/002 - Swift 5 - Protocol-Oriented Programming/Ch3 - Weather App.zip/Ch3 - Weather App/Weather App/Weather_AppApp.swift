//
//  Weather_AppApp.swift
//  Weather App
//
//  Created by user234476 on 3/14/23.
//

import SwiftUI

@main
struct Weather_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  OpenWeatherController.swift
//  Weather App
//
//  Created by user234476 on 3/14/23.
//

import Foundation

class OpenWeatherController: WebServiceController {
    func fetchWeatherData(for city: String, completionHandler: (String, WebServiceControllerError) -> Void) {
        <#code#>
    }
    
    
}

//
//  ContentView.swift
//  Weather App
//
//  Created by user234476 on 3/14/23.
//

import SwiftUI

struct ContentView: View {
    @State var input: String = ""
    var body: some View {
        
        VStack {
            TextField("City Name:", text: $input)
                .padding()
                .font(.title)
            Divider()
            Text(input)
                .font(.body)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

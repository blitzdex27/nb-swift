//
//  OpenWeatherController.swift
//  Weather App
//
//  Created by user234476 on 3/14/23.
//

import Foundation

class OpenWeatherController: WebServiceController {
    func fetchWeatherData(for city: String, completionHandler: (String, WebServiceControllerError) -> Void) {
        // https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
	// 07d453acec076c2c3bf1dd48ce87c530
    }
    
    
}

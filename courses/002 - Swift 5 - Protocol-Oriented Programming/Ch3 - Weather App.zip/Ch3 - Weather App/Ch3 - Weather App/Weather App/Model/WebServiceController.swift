//
//  WebServiceController.swift
//  Weather App
//
//  Created by user234476 on 3/14/23.
//

import Foundation

public enum WebServiceControllerError: Error {
    case invalidURL(String)
    case invalidPayload(URL)
    case forwarded(Error)
}

public protocol WebServiceController {
    func fetchWeatherData(for city: String,
                          completionHandler: (_ weatherCondition: String, _ error:WebServiceControllerError) -> Void)
}
